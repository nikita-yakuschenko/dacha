
(()=>{
const root=document.getElementById('mb-landing');
let saved={};
try { saved=JSON.parse(localStorage.getItem('minibrus-concept-preferences')||'{}'); } catch {}
const state={mode:saved.mode==='build'?'build':'kit',project:['4 × 5 м','4 × 6 м','5 × 6 м'].includes(saved.project)?saved.project:'4 × 6 м',step:0,notes:true};
const $=s=>root.querySelector(s);const $$=s=>Array.from(root.querySelectorAll(s));
function save(){try { localStorage.setItem('minibrus-concept-preferences',JSON.stringify({mode:state.mode,project:state.project})); } catch {}}
function render(){
root.classList.toggle('mb-show-notes',state.notes);$('.mb-note-toggle').setAttribute('aria-pressed',String(state.notes));
$$('[data-mode]').forEach(e=>e.setAttribute('aria-pressed',String(e.dataset.mode===state.mode)));
$$('[data-choice-mode]').forEach(e=>e.setAttribute('aria-pressed',String(e.dataset.choiceMode===state.mode)));
$$('[data-size]').forEach(e=>e.setAttribute('aria-pressed',String(e.dataset.size===state.project)));
$$('[data-step]').forEach(e=>e.hidden=Number(e.dataset.step)!==state.step);
$$('[data-step-label]').forEach(e=>e.dataset.active=String(Number(e.dataset.stepLabel)===state.step));
$('#mb-back').style.visibility=state.step===0?'hidden':'visible';
$('#mb-next').textContent=state.step===3?'Получить расчёт моего дома':'Дальше →';
$('#mb-zone-note').textContent=state.mode==='build'?'Проверим возможность монтажа: Нижегородская область и ориентировочно до 500 км от Нижнего Новгорода.':'Стоимость и доступность доставки проверим для вашего населённого пункта.';
$('#mb-summary').textContent=state.project+' · '+(state.mode==='kit'?'комплект с доставкой':'дом с монтажом')+($('#mb-location').value?' · '+$('#mb-location').value:'');
$$('.mb-price').forEach(e=>{e.firstChild.textContent=state.mode==='kit'?'Цена комплекта: ':'Цена с монтажом: ';});
$$('.mb-price-note').forEach(e=>e.textContent=state.mode==='kit'?'Доставка и разгрузка — отдельно':'Условия участка и состав работ — по смете');
}
function openCalc(mode,project){if(mode==='kit'||mode==='build')state.mode=mode;if(project)state.project=project;state.step=project?2:0;$('#mb-form-status').textContent='';render();save();$('#mb-calc').scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});}
$$('[data-open]').forEach(e=>e.addEventListener('click',()=>openCalc(e.dataset.open)));
$$('[data-project]').forEach(e=>e.addEventListener('click',()=>openCalc('current',e.dataset.project)));
$$('[data-mode]').forEach(e=>e.addEventListener('click',()=>{state.mode=e.dataset.mode;render();save();}));
$$('[data-choice-mode]').forEach(e=>e.addEventListener('click',()=>{state.mode=e.dataset.choiceMode;render();save();}));
$$('[data-size]').forEach(e=>e.addEventListener('click',()=>{state.project=e.dataset.size;render();save();}));
$('#mb-back').addEventListener('click',()=>{state.step=Math.max(0,state.step-1);$('#mb-form-status').textContent='';render();});
$('#mb-next').addEventListener('click',()=>{
const status=$('#mb-form-status');status.textContent='';
if(state.step===2&&!$('#mb-location').value.trim()){status.textContent='Укажите населённый пункт для проверки логистики.';$('#mb-location').focus();return;}
if(state.step<3){state.step++;render();return;}
if(!$('#mb-contact').value.trim()){status.textContent='Укажите контакт для демонстрации формы.';$('#mb-contact').focus();return;}
if(!$('#mb-consent').checked){status.textContent='Отметьте согласие, чтобы продолжить демонстрацию.';return;}
status.textContent='Демонстрация завершена: выбран '+state.project+' ('+(state.mode==='kit'?'комплект с доставкой':'дом с монтажом')+'). Данные никуда не отправлены.';
});
$('#mb-channel').addEventListener('change',()=>{const tg=$('#mb-channel').value==='telegram';$('#mb-contact-label').textContent=tg?'Имя пользователя Telegram':'Номер телефона';$('#mb-contact').type=tg?'text':'tel';$('#mb-contact').placeholder=tg?'@username':'+7 (___) ___-__-__';});
$('#mb-custom-form').addEventListener('submit',e=>{e.preventDefault();$('#mb-custom-status').textContent='Демонстрация: свой вариант выбран. Данные не отправлены.';});
$('.mb-note-toggle').addEventListener('click',()=>{state.notes=!state.notes;render();});
render();
})();

